n=int(input("Enter any one number:"))

f=1

for i in range(1,n+1):

 f=f*i

 print("Factorial of ",n,"is",f)